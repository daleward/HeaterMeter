MeterMonitorver2 — packaged sketch
==================================
Contents:
  • MeterMonitorver2/            — the Arduino sketch folder
  • libraries/                   — optional placeholder for manual library installs
  • scripts/                     — one-click installers using Arduino CLI
  • README.txt                   — this file

Required Arduino Libraries:
  1) WiFiManager (by tzapu) — install via Library Manager
  2) TM1637Display (by Avishay Orpaz) — install via Library Manager
  3) HeaterMeterClient (by CapnBry) — copy from HeaterMeter repo

Quick setup (Arduino IDE):
  A) Open Arduino IDE, go to Sketch → Include Library → Manage Libraries…
     • Install “WiFiManager” (by tzapu, maintainer tablatronix).
     • Install “TM1637Display” (by Avishay Orpaz).
  B) Get HeaterMeterClient from the HeaterMeter repository and put the folder into your sketchbook 'libraries' folder.
     Path: arduino/libraries/HeaterMeterClient inside the repo.
  C) Open MeterMonitorver2/MeterMonitorver2.ino and set your Wi‑Fi SSID/PASSWORD.
  D) Select your ESP8266 board and upload over USB.

Optional (Arduino CLI automated install):
  • Windows: scripts\install_libraries_windows.bat
  • macOS/Linux: scripts/install_libraries_mac_linux.sh
