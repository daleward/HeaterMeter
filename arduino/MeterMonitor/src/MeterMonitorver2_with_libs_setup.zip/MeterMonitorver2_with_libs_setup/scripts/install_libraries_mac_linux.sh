\
    #!/usr/bin/env bash
    set -e
    echo "Installing required libraries with Arduino CLI..."
    echo "If you don't have Arduino CLI, see: https://arduino.github.io/arduino-cli"

    arduino-cli core update-index
    # WiFiManager and TM1637Display from Library Manager
    arduino-cli lib install "WiFiManager" "TM1637Display"

    cat <<'EOF'

    -----------------------------------------------------
    HeaterMeterClient is not in Library Manager.
    1) Open GitHub:
       https://github.com/CapnBry/HeaterMeter/tree/master/arduino/libraries/HeaterMeterClient
    2) Download the folder and place it into:
       macOS:  ~/Documents/Arduino/libraries/HeaterMeterClient
       Linux:  ~/Arduino/libraries/HeaterMeterClient
    -----------------------------------------------------
    EOF
