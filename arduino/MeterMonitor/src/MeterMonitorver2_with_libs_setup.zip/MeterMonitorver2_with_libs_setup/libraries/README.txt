This 'libraries' folder is optional. You can place any custom or manually-downloaded Arduino libraries here
before moving the folders into your Arduino sketchbook's 'libraries' directory.

Required libraries for MeterMonitorver2:
  1) WiFiManager (by tzapu)  — install via Arduino Library Manager
  2) TM1637Display (by Avishay Orpaz) — install via Arduino Library Manager
  3) HeaterMeterClient (by CapnBry) — copy from the HeaterMeter repository

Notes:
  • WiFiManager and TM1637Display are best installed through the IDE's Library Manager.
  • HeaterMeterClient isn't in Library Manager. Fetch it from the HeaterMeter repo and place the 'HeaterMeterClient'
    folder (with .h/.cpp and library.properties) into your Documents/Arduino/libraries/ directory.
