HeaterMeterClient library (placeholder)
--------------------------------------
Get the real library from the HeaterMeter project:
  • GitHub repo: CapnBry/HeaterMeter  (path: arduino/libraries/HeaterMeterClient)
  • Wiki/Thread reference shows this library name in use.

After downloading, this folder should contain files like:
  • HeaterMeterClient.h
  • HeaterMeterClient.cpp
  • library.properties
  • (optional) examples/

Install instructions:
  1) Copy this 'HeaterMeterClient' folder into your Arduino sketchbook 'libraries' directory, e.g.:
     Windows:  %USERPROFILE%\Documents\Arduino\libraries\HeaterMeterClient
     macOS:    ~/Documents/Arduino/libraries/HeaterMeterClient
     Linux:    ~/Arduino/libraries/HeaterMeterClient
  2) Restart Arduino IDE.
